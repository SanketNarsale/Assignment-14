import { Component } from '@angular/core';

@Component({
  selector: 'app-invalidpage',
  standalone: true,
  imports: [],
  templateUrl: './invalidpage.component.html',
  styleUrl: './invalidpage.component.css'
})
export class InvalidpageComponent {

}
