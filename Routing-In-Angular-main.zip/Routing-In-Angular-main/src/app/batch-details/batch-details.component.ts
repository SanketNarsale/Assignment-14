import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-batch-details',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './batch-details.component.html',
  styleUrl: './batch-details.component.css'
})
export class BatchDetailsComponent {
  public technology=[
    {"Name" : "AI" ,"Book":"abc" },
    {"Name" : "ML" ,"Book":"pqr" },
    {"Name" : "Angular", "Book":"wxy"},
    {"Name" : "AWS" ,"Book":"qwe"}
  ]

}
